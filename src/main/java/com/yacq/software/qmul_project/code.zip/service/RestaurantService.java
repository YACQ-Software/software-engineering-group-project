package com.yacq.software.qmul_project.service;

import org.springframework.stereotype.Service;

@Service
public class RestaurantService {
    public String getGreeting() {
        return "Hello Restaurant";
    }
}